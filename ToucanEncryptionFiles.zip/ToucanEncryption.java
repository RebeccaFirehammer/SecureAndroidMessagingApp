package com.example.fuzail.pgpencrypttest;

/**
 * Created by fuzail on 4/29/17.
 * Unable to get PGP encryption to work (for some reason I can't import "java.nio.file.*" on line 14), defaulting to Blowfish
 */

import javax.crypto.*;
import javax.crypto.spec.*;

//import java.io.*;
//import java.nio.charset.Charset;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.*;

public class ToucanEncryption {

//    private static final String PASSPHRASE = "test";
//
//    private static final String DE_INPUT = "decrypt.pgp";
//    private static final String DE_OUTPUT = "output.txt";
//    private static final String DE_KEY_FILE = "src/test/secring.skr";
//
//    private static final String E_INPUT = "encrypt.txt";
//    private static final String E_OUTPUT = "output.pgp";
//    private static final String E_KEY_FILE = "src/test/pubring.pkr";

    public static String tier1Encrypt(String s, String pwd) throws Exception {
        String temp;
        try{
            temp = encrypt(s,pwd);
        } catch (Exception e){
            e.printStackTrace();
            throw new Exception(e);
        }
        return temp;
    }

//    public static String tier2Encrypt(String s, String pwd) throws Exception {
//
//        try{
//            PrintWriter writer = new PrintWriter(E_INPUT, "UTF-8");
//            writer.println(s);
//            writer.close();
//        } catch (IOException e) {
//            // do something
//        }
//
//        PGPFileProcessor p = new PGPFileProcessor();
//        p.setInputFileName(E_INPUT);
//        p.setOutputFileName(E_OUTPUT);
//        p.setPassphrase(pwd);
//        p.setPublicKeyFileName(E_KEY_FILE);
//        System.out.println(p.encrypt());
//
//        String temp = readFile(E_OUTPUT, StandardCharsets.UTF_8);
//
//        try{
//            temp = tier1Encrypt(temp, pwd);
//        } catch (Exception e){
//            e.printStackTrace();
//            throw new Exception(e);
//        }
//        return temp;
//    }

    public static String tier1Decrypt(String s, String pwd) throws Exception {
        String temp;
        try{
            temp = decrypt(s,pwd);
        } catch (Exception e){
            e.printStackTrace();
            throw new Exception(e);
        }
        return temp;
    }

//    public static String tier2Decrypt(String s, String pwd) throws Exception {
//
//        try{
//            PrintWriter writer = new PrintWriter(DE_INPUT, "UTF-8");
//            writer.println(s);
//            writer.close();
//        } catch (IOException e) {
//            // do something
//        }
//
//        PGPFileProcessor p = new PGPFileProcessor();
//        p.setInputFileName(DE_INPUT);
//        p.setOutputFileName(DE_OUTPUT);
//        p.setPassphrase(pwd);
//        p.setSecretKeyFileName(DE_KEY_FILE);
//        System.out.println(p.decrypt());
//
//        String temp = readFile(DE_OUTPUT, StandardCharsets.UTF_8);
//
//        try{
//            temp = tier1Decrypt(temp, pwd);
//        } catch (Exception e){
//            e.printStackTrace();
//            throw new Exception(e);
//        }
//        return temp;
//    }

    private static String encrypt(String strClearText,String strKey) throws Exception {
        String strData = "";
        try {
            SecretKeySpec skeyspec = new SecretKeySpec(strKey.getBytes(), "Blowfish");
            Cipher cipher = Cipher.getInstance("Blowfish");
            cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
            byte[] encrypted = cipher.doFinal(strClearText.getBytes());
            strData = new String(encrypted);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e);
        }
        return strData;
    }
    private static String decrypt(String strEncrypted,String strKey) throws Exception {
        String strData="";

        try {
            SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
            Cipher cipher=Cipher.getInstance("Blowfish");
            cipher.init(Cipher.DECRYPT_MODE, skeyspec);
            byte[] decrypted=cipher.doFinal(strEncrypted.getBytes());
            strData=new String(decrypted);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e);
        }
        return strData;
    }

//    private static String readFile(String path, Charset encoding)
//            throws IOException
//    {
//        byte[] encoded = Files.readAllBytes(Paths.get(path));
//        return new String(encoded, encoding);
//    }
}
